import { useState, useEffect } from "react";
import { useScrollReveal } from "../hooks/useScrollReveal";

const reviews = [
  {
    quote: "PixelPro completely transformed our brand. The logo, social media creatives, and video edits were all outstanding. Raghav is incredibly talented and delivers fast.",
    name: "Kapil Sharma",
    role: "Founder, StudioWave",
    stars: 5,
    initial: "K",
    color: "#F97316",
  },
  {
    quote: "I enrolled in the Graphic Design course and it's been the best investment I've made. The teaching style is practical, hands-on, and the trainer really knows the industry.",
    name: "Priya Mehta",
    role: "Student · Graphic Design Batch",
    stars: 5,
    initial: "P",
    color: "#3B82F6",
  },
  {
    quote: "The video editing course is top-notch. After just 2 months I was able to start taking freelance clients. The portfolio work we built during the course was the key.",
    name: "Aakash Verma",
    role: "Student · Video Editing Batch",
    stars: 5,
    initial: "A",
    color: "#10B981",
  },
];

const Stars = ({ count }) => (
  <div className="flex gap-0.5 mb-4">
    {Array.from({ length: count }).map((_, i) => (
      <svg key={i} width="14" height="14" viewBox="0 0 24 24" fill="#F97316">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
      </svg>
    ))}
  </div>
);

export default function Testimonial() {
  const [active, setActive] = useState(0);
  const [animating, setAnimating] = useState(false);
  const { ref, visible } = useScrollReveal({ threshold: 0.15 });

  // Auto-rotate
  useEffect(() => {
    const t = setInterval(() => {
      setAnimating(true);
      setTimeout(() => {
        setActive((a) => (a + 1) % reviews.length);
        setAnimating(false);
      }, 280);
    }, 5000);
    return () => clearInterval(t);
  }, []);

  const goTo = (i) => {
    if (i === active) return;
    setAnimating(true);
    setTimeout(() => { setActive(i); setAnimating(false); }, 280);
  };

  const r = reviews[active];

  return (
    <section
      ref={ref}
      className="bg-[#fdf9f0] py-16 md:py-20 px-5 sm:px-8 lg:px-14 border-t border-orange-100"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "none" : "translateY(24px)",
        transition: "opacity 0.6s cubic-bezier(0.16,1,0.3,1), transform 0.6s cubic-bezier(0.16,1,0.3,1)",
      }}
    >
      <div className="max-w-[860px] mx-auto">
        <div className="text-center mb-10">
          <p className="text-[11px] font-bold text-[#F97316] tracking-[3px] uppercase mb-3">Reviews</p>
          <h2 className="text-[28px] sm:text-[32px] font-bold text-[#1a1a2e] tracking-tight">What People Say</h2>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl border border-orange-100 px-7 md:px-12 py-8 md:py-10 shadow-sm text-center relative overflow-hidden">
          {/* Background quote mark */}
          <div className="text-[120px] leading-none text-[#F97316]/8 font-serif select-none absolute -top-4 left-6 pointer-events-none">"</div>

          <div
            style={{
              opacity: animating ? 0 : 1,
              transform: animating ? "translateY(8px)" : "none",
              transition: "opacity 0.28s ease, transform 0.28s ease",
            }}
          >
            {/* Avatar */}
            <div className="flex justify-center mb-4">
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center text-white text-[20px] font-black shadow-lg"
                style={{ background: r.color }}
              >
                {r.initial}
              </div>
            </div>
            <Stars count={r.stars} />
            <p className="text-[15px] md:text-[17px] text-[#1a1a2e] leading-[1.8] font-medium mb-6 max-w-[640px] mx-auto">
              {r.quote}
            </p>
            <p className="text-[14px] font-bold text-[#F97316]">{r.name}</p>
            <p className="text-[11px] font-semibold text-gray-400 tracking-[1.2px] uppercase mt-1">{r.role}</p>
          </div>
        </div>

        {/* Navigation dots */}
        <div className="flex items-center justify-center gap-2.5 mt-6">
          {reviews.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              aria-label={`Review ${i + 1}`}
              className={`rounded-full transition-all duration-300 ${
                i === active ? "bg-[#F97316] w-6 h-2" : "bg-[#F97316]/25 hover:bg-[#F97316]/50 w-2 h-2"
              }`}
            />
          ))}
        </div>

        {/* Google rating badge */}
        <div className="mt-8 flex justify-center">
          <div className="inline-flex items-center gap-3 bg-white border border-gray-100 rounded-full px-5 py-2.5 shadow-sm">
            <div className="flex gap-0.5">
              {[1,2,3,4,5].map((s) => (
                <svg key={s} width="13" height="13" viewBox="0 0 24 24" fill="#F97316">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
              ))}
            </div>
            <span className="text-[12px] font-bold text-[#1a1a2e]">5.0</span>
            <span className="text-[12px] text-gray-400">·</span>
            <span className="text-[12px] text-gray-500">34 reviews on Google</span>
          </div>
        </div>
      </div>
    </section>
  );
}