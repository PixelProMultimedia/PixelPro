import { useScrollReveal } from "../hooks/useScrollReveal";

const logos = [
  { name: "Tech Karnal",   initials: "TK" },
  { name: "StudioWave",    initials: "SW" },
  { name: "RealtyPlus",    initials: "RP" },
  { name: "FoodieHub",     initials: "FH" },
  { name: "NovaBrand",     initials: "NB" },
  { name: "UrbanCraft",    initials: "UC" },
];

export default function Customers() {
  const { ref, visible } = useScrollReveal({ threshold: 0.15 });

  return (
    <section
      ref={ref}
      className="bg-gray-50 py-12 md:py-16 px-5 sm:px-8 lg:px-14 border-t border-gray-100"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "none" : "translateY(20px)",
        transition: "opacity 0.6s cubic-bezier(0.16,1,0.3,1), transform 0.6s cubic-bezier(0.16,1,0.3,1)",
      }}
    >
      <div className="max-w-[1280px] mx-auto">
        <p className="text-center text-[11px] font-bold text-gray-400 uppercase tracking-[3px] mb-8">
          Trusted by brands in Karnal &amp; beyond
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6">
          {logos.map((logo) => (
            <div
              key={logo.name}
              className="flex items-center gap-2.5 bg-white border border-gray-200 rounded-xl px-5 py-3 shadow-sm hover:shadow-md hover:border-orange-200 transition-all duration-200"
            >
              <div className="w-8 h-8 rounded-lg bg-[#F97316]/10 flex items-center justify-center">
                <span className="text-[11px] font-black text-[#F97316]">{logo.initials}</span>
              </div>
              <span className="text-[13px] font-semibold text-gray-700">{logo.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}